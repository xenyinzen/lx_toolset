#!/bin/sh
# WARNING: This file was auto-generated. Do not edit!
CC='cc -O2 -DPOSIX -c'
LD='cc -s'
