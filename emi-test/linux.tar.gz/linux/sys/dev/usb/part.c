struct block_dev_desc_t ;
void dev_print(struct block_dev_desc_t *dev_desc)
{
}
