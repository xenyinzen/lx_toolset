/*	$OpenBSD: setjmp.h,v 1.2 1999/01/27 04:46:06 imp Exp $	*/

/*
 * mips/setjmp.h: machine dependent setjmp-related information.
 */

#ifndef _MIPS_SETJMP_H_
#define _MIPS_SETJMP_H_

#define	_JBLEN	83		/* size, in longs, of a jmp_buf */

#endif /* !_MIPS_SETJMP_H_ */
