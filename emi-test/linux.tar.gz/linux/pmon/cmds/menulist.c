/*
 * Copyright (c) 2007 SUNWAH HI-TECH  (www.sw-linux.com.cn)
 * Wing Sun	<chunyang.sun@sw-linux.com>
 * Weiping Zhu<weiping.zhu@sw-linux.com>
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by Opsycon AB, Sweden.
 * 4. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/errno.h>
#include <sys/endian.h>
#include <sys/device.h>

#include <stdio.h>
#include <stdarg.h>
#include <termio.h>
#ifdef _KERNEL
#undef _KERNEL
#include <sys/ioctl.h>
#define _KERNEL
#else
#include <sys/ioctl.h>
#endif

#include <pmon.h>
#include <exec.h>
#include <pmon/loaders/loadfn.h>

#ifdef __mips__
#include <machine/cpu.h>
#endif

#define MAXARGS 256

#define MAX_TIME_OUT 1000
#define MAX_MENU_ITEMS_SHOW 10
#define MENU_START_LINE 3
#define MENU_TITLE_BUF_LEN 79

#define MENU_TITLE "Loongson System Boot Menus"
#define MENU_TITLE_LEN strlen(MENU_TITLE)

#define OPTION_LEN	50
#define GLOBAL_VALUE_LEN 256

typedef struct menu_option
{
	char option [OPTION_LEN + 1];
	char value 	[GLOBAL_VALUE_LEN + 1];
}MenuOptions;

#define VALUE_LEN	1024

typedef struct _Menu_Item_
{
	char title 	[MENU_TITLE_BUF_LEN + 1];	//Title of menu item, display on screen.
	char * kernel ;	//kernel file to load.
	char * args	;	//arguments for kernel.
	char * initrd ;	//initrd file for kernel, maybe empty.
	char * root;	//ROOT device from args.
}Menu_Item;

#define issep(ch) ((ch) == ' ' || (ch) == '\t')

#define CDROM 0
#define IDE 1

#define TEXT_COLOR 15
#define SELECTED_BGCOLOR 1
#define UNSELECTED_BGCOLOR 0

extern int get_console_cols();
#define LINE_BEGIN 		1  // Begin of a line on screen.
#define LINE_END  		(get_console_cols() - 2) // END of a line on screen.
#define LEFT_MARGIN 	4  // 4 SPACES left margin.
#define RIGHT_MARGIN 	4  // 4 SPACES right margin.

#define LINE_MAX_LENGTH 1024

// for old code choose menu by input number for menu index.
#define ANY_KEY_STOP 
#undef KEY_INPUT_CHOOSE
/*
 * These two MACRO only for old way to use menu.
 * We didn't use this way anymore,so disable it.
 */


static int OpenLoadConfig __P((const char* filename));
static int menu_list_read __P((ExecId, int, int));
static char* trim __P((char *line));
static int print_boot_menu __P((int flag));
static char* GetTitle __P((const char *str,char * title, int title_buf_len));
static int GetOption __P((char *str, char *option, int option_len, char *value, int val_len));
static int boot_load __P((int index));
static void set_option_value __P((const char* option, const char* value));
static const char* get_option_value __P((const char* option));
static int do_cmd_menu_list __P((int flag, const char* path));
static int do_list_menu __P((int flag, const char* path));
static void remove_comment __P((char *str));
static int do_cmd_boot_load __P((int boot_id, int device_flag));
void empty_line_part __P((int row, int begin, int end, int bgcolor));
void empty_line(int line_no,int bgcolor);
int check_config __P((const char * file));
int check_ide __P(());
int check_cdrom __P(());

extern void __cprint(int y, int x, int width, char color, const char *buf);
extern void cprintf(int y, int x, int width, char color, const char *fmt, ...);
extern void video_cls(void);
extern void video_drawstring(int, int, const char*);
extern void video_console_print(int console_col, int console_row, unsigned char *s);
extern void gui_print(int row, int col, int width, int forecolor, int bgcolor, const char *str);
extern void _set_font_color(void);

static Menu_Item menu_items[MAXARGS];//Storage All menu information.
static int menus_num = 0;
static MenuOptions menu_options[] = {
	{"showmenu", "1"}, //indentfy to show or not show menu for user.
	{"default", "0"}, //default menu to boot.
	{"timeout", "5"},//default timeout in seconds wait for user.
};
static int menu_start;// The first menu item in config file to show on screen.
static int menu_end; // The last menu item in config file to show on screen.
static int menu_len;// The Total menu items include System menu.
static int ex_menu_count; //How many extra menu will to be show?
static int has_cdrom =0; //Exist a cdrom?0 not ,1 yeah.

static int options_num = sizeof(menu_options) / sizeof(menu_options[0]);

void cut_string(char *buf)
{
	if( strlen(buf) <= LINE_END - LINE_BEGIN - LEFT_MARGIN - RIGHT_MARGIN + 1 )
		return;
	if( buf [LINE_END - LINE_BEGIN - LEFT_MARGIN - RIGHT_MARGIN + 1] != '\0')
	{
		buf [LINE_END - LINE_BEGIN - LEFT_MARGIN - RIGHT_MARGIN + 1 ] 	= '.' ;
		buf [LINE_END - LINE_BEGIN - LEFT_MARGIN - RIGHT_MARGIN ] 		= '.' ;
		buf [LINE_END - LINE_BEGIN - LEFT_MARGIN - RIGHT_MARGIN - 1 ] 	= '.' ;
	}
}

static void set_option_value(const char* option, const char* value)
{
	int i = 0;

	for (i = 0; i < options_num; i++)
	{
		if (strcasecmp (option, menu_options[i].option) == 0)
		{
			strncpy (menu_options[i].value, value, GLOBAL_VALUE_LEN);
			return;
		}
	}
}

static const char* get_option_value(const char* option)
{
	int i = 0;

	for (i = 0; i < options_num; i++)
	{
		if (strcasecmp(option, menu_options[i].option) == 0)
			return menu_options[i].value;
	}
	return NULL;
}

/**********************************************************
 * Delete SPACE and TAB from begin and end of the str.
 * Also delete \r\n at the end of the str.
 * Final check is the comment line.
**********************************************************/
static char* trim(char *string)
{
  int len;
  char * str= string;

  len = strlen(str);
  while( len && (str[len-1] == '\n' || str[len-1] == '\r' ||
		  issep (str[len-1]) ) )
	  str[--len] = '\0';
  
  while( issep (*str) )
	  str++;
  
  if (*str == '#')
	  *str = '\0';
  
  return str;
}

/**********************************************************
 * Read a line from fd into buf.
 *********************************************************/
static int ReadLine(ExecId id, int fd, char *buf, int buflen)
{
  int len, n;

  n = 0;
  len = buflen - 1;
  
  while( 1 )
  {
	  if( exec (id, fd, buf, &len, 0) <= 0 )//read data from fd.
		  break;//end of file or error.

	  n++;
	  
	  buf[len] = '\0';
	  while( len && (buf[len-1] == '\n' || buf[len-1] == '\r') )
	  {
		  buf[--len] = '\0';
	  }

	  if( len && buf[len-1] == '\\' )
	  {
		  //prepare to read another new data to buf.
		  buf += len - 1;
		  buflen -= len - 1;
		  if( !buflen )        /* No buffer space */
			  break;
	  }
	  else
		  break;
  }

  return n;
}

/*************************************************************
 * Remove comment information from string.
*************************************************************/

static void remove_comment(char *str)
{
  //int instring;

  char *p;
  p = str;

//  instring = 0;
  while( *p )
  {
	switch( *p )
	{
		case '"':
		case '\'':
//			instring = !instring;
			break;
		case '#':
//			if( !instring )
				*p = '\0';
			return;
	}
	++p;
  }

}

/*********************************************************************
 * Split string to two part, string delimit by the SPACE or TAB.
 * char * str , strings need to be splited.
 * char * strings[2], buffer to storage splited strings.
*********************************************************************/

static int split_str(const char * str,char * strings[2])
{
	char * p;
	char * p1;
	char * p2;

	//check input data buf.
	if( !str || !strings)
		return -1 ;
	if( !strings[0] || !strings [1] )
		return -1;

	//Remove SPACE or TAB from header and tail.
	p = trim(str);
	//if is empty line or comment data.
	if( *p == '\0' || *p == '#')
		return -1;
	//found where is the SPACE or TAB.
	p1 = index (str, ' ');
	p2 = index (str, '\t');

	//Get the first position.
	if( p1 < p2 )
		p = p1 ? p1:p2;
	else
		p = p2 ? p2:p1;
	
	if( p )// if found copy data.
	{
		strncpy (strings[0], str, p - str);
		strcpy (strings[1], p);
		return 2;
	}
	else
		strcpy (strings[0], str);
	return 1;
}

/*********************************************************************
 * Split string to key and value.
 * char * str, string to be splited
 * char * option, buffer to stor key.
 * int option_len, length of the buffer option.
 * char * value, buffer to stor value.
 * int value_len, length of the buffer value.
 * return -1 for failed, 0 for success.
*********************************************************************/

static int GetOption (char *str, char *option, int option_len, char *value,
					  int val_len)
{
	char *argv[2];
	char key [MENU_TITLE_BUF_LEN +1] = {0};
	char val [VALUE_LEN +1] = {0};
	char *p;
	int argc;

	argv[0] = key;
	argv[1] = val;

	//split string to two part,key and value ,splited by SPACE or TAB
	argc = split_str (str, argv);

	//if split to two part, return 2.
	if( argc < 2 )
		return -1;

	//remove SPACE and TAB from key and val header and tail.
	p = trim (key);
	//copy to buffer.
	strncpy (option, p, option_len - 1);

	p = trim (val);
	//remove comment data from string.
	remove_comment(p);
	strncpy (value, p, val_len -1);

	return 0;
}

/******************************************************************
 * Extract the menu title from string.
 * const char * str, the string include menu title information.
 * Return the menu title,if found, else return NULL.
******************************************************************/

static char* GetTitle(const char *str,char * title, int title_buf_len)
{
	char *argv[2];
	char key [MENU_TITLE_BUF_LEN +1] = {0};
	char value [VALUE_LEN +1] = {0};
	char *p;
	int argc, len;
  
	argv[0] = key;
	argv[1] = value;

	//Parse string.
	argc = split_str (str, argv);

	if( argc < 1 )
		return -1;

	if( argc == 1 )
	{
		//Support for OLD style lable
		len = strlen (argv[0]);
		if( argv[0][len -1] == ':')
		{
			argv[0][len -1] = '\0';
			p=trim(argv[0]);
			//remove SPACE and TAB from begin and end of string.
			strncpy(title,p,title_buf_len);
			return 0;
		}
	}
	else
	{
		//remove SPACE and TAB from begin and end of string.
		p = trim (key);
		//check key.
		if( strcasecmp (p, "title") == 0 )
		{
			//remove SPACE and TAB from begin and end of string.
			p = trim (value);
			//remove comment data from string.
			remove_comment(p);
			strncpy (title, p, title_buf_len);
			return 0;
		}
	}
	return -1;
}

/*************************************************************************
 * Read menu config file and initial data struct to storage information.
*************************************************************************/

static int menu_list_read(ExecId id, int fd, int flags)
{
	int j;//index for current menu item.
	char buf[1025];
	char buf_bak[1025];
	int buflen = 1024;
	int n = 0;
	char* cp = NULL;
	char option[OPTION_LEN] = {0};
	char value[VALUE_LEN] = {0};
	int in_menu = 0;
	char title [MENU_TITLE_BUF_LEN + 1];//Title of menu item, display on screen.
	
	for (j = 0; j < MAXARGS; j++)
	{
		memset (menu_items + j, 0, sizeof(menu_items[j]));
	//	memset (menu_items[j].title, 0, MENU_TITLE_BUF_LEN + 1 );
	}
	
	j = -1; //set to 0;
	n = 0;
	while (ReadLine(id, fd, buf, buflen) > 0)//Read a line.
	{
		memset(title,0, MENU_TITLE_BUF_LEN + 1 );
		n++;

		strcpy(buf_bak, buf);//Got a copy of buf.
		cp = trim(buf);//Trim space
		if (*cp == '\0' || *cp == '#')//If only a empty line,or comment line, drop it.
		{
			continue;
		}
		
		//Check data, looking for menu title.
		if( GetTitle (cp, title, MENU_TITLE_BUF_LEN ) == 0) 
		{
			j++;
			strncpy (menu_items[j].title, title, MENU_TITLE_BUF_LEN);//storage it.
			if(menu_items[j].kernel == NULL)
			{
				menu_items[j].kernel = malloc (VALUE_LEN + 1);
				menu_items[j].args = malloc (VALUE_LEN + 1);
				menu_items[j].initrd = malloc (VALUE_LEN + 1);
				menu_items[j].root = malloc (VALUE_LEN + 1);
			}
			memset (menu_items[j].kernel, 0, VALUE_LEN + 1);
			memset (menu_items[j].args, 0, VALUE_LEN + 1);
			memset (menu_items[j].initrd, 0, VALUE_LEN + 1);
			memset (menu_items[j].root, 0, VALUE_LEN + 1);
			in_menu = 1;
			continue;
		}

		cp = trim(buf_bak);
		if( in_menu )
		{	
			//Read all properties of current menu item.
			if( GetOption (cp,option,OPTION_LEN,value,VALUE_LEN) == 0 )
			{
				if( strcasecmp (option,"kernel") == 0 ) // got kernel property
				{
					if( menu_items[j].kernel != NULL && menu_items[j].kernel[0] == '\0') // we only sotr the firs kernel property, drop others.
						strncpy(menu_items[j].kernel,value,VALUE_LEN);
				}
				else if( strcasecmp (option,"args") == 0 )// got kernel arguments property.
				{
					if( menu_items[j].args != NULL && menu_items[j].args[0] == '\0')//same as the kernel property.
						strncpy(menu_items[j].args,value,VALUE_LEN);
				}
				else if( strcasecmp (option,"initrd") == 0 )// go initrd kernel arguments property, may be null.
				{
					if( menu_items[j].initrd!= NULL && menu_items[j].initrd[0] == '\0')// same as the kernel property.
						strncpy(menu_items[j].initrd,value,VALUE_LEN);
				}
				else if (strcasecmp(option, "root") == 0)
				{
					if (menu_items[j].root != NULL && menu_items[j].root[0] == '\0')
					{
						strncpy(menu_items[j].root, value, VALUE_LEN);
					}
				}
				//drop other property.
			}
		}
		else // out of menu item.
		{
			//Check data, looking for global option.
			if( GetOption (cp,option,OPTION_LEN,value,VALUE_LEN) == 0 )
			{
				set_option_value(option, value);//storage it.
			}
		}
	}
	menus_num = j + 1;
	return menus_num > 0 ? 0 : -1;
}
/*********************************************************************
 * Print a EMPTY LINE on screen,
 * used for clean up a LINE.
 * int row where to draw.
 * int bgcolor which color to draw.
*********************************************************************/

void empty_line(int row,int bgcolor)
{
//	empty_line_part(row,0,80,bgcolor);
	empty_line_part(row, 0, get_console_cols(), bgcolor);
}

void empty_line_part(int row, int begin, int end, int bgcolor)
{
	int k;
	for( k = begin; k < end; k++ )
		gui_print (row, k, 0, TEXT_COLOR, bgcolor, (unsigned char *)" ");
	_set_font_color();
}

#ifdef TEXT_COLOR_DEBUG
void draw_text()
{
	int i,k;
	char buf[512];
	for( i = 12; i< 20 ; i=i+2)
	{
		for( k = 0; k < 80; k++ )
		{
			sprintf(buf,"%02d",k);
			gui_print (i, k, 0, k+i-12, 0, buf);
			gui_print (i+1, k, 0, k+i-12, 1, buf);
		}
	}
}
#endif
// return Extra menu item num for flag
// flag is CDROM return 1;
// flag is IDE and exist cdrom return 1;
// else return 0;
static int extra_menu(int flag)
{
	if( flag == IDE && check_cdrom () )
		return 1;
	else if( flag == CDROM )
		return 1;
	return 0;
}

/*********************************************************************
 * Draw help information on screen.
*********************************************************************/
static void draw_help(int row)
{
//	char buff[LINE_WIDTH]={0};
	char* buff = NULL;
	int line_width = 0;
	
	line_width = get_console_cols();

	buff = malloc(line_width);
	if (buff == NULL)
	{
		return ;
	}
	memset(buff, 0, line_width);
	_set_font_color ();

	sprintf(buff,"Use %c/PageUp,%c/PageDown,HOME,END keys to navigate menu.",DISP_UP,DISP_DOWN);
	video_console_print(1, row++ , buff);
	sprintf(buff,"Press ENTER to boot selected OS.");
	video_console_print(1, row++ , buff);

	free(buff);
}

/*********************************************************************
 * Draw a LINE on screen .
 * int row, where to draw.
*********************************************************************/

static void draw_line(int row)
{
	int k;
	char buf[2] = {0};

	buf[0] = DISP_HORIZ;
	_set_font_color ();

	for( k = LINE_BEGIN; k <= LINE_END; k++ )
		video_console_print (k, row, buf);
}

/*********************************************************************
 * Draw MENU on screen.
 * char * menu [] , array to storage the all menu.
 * int flag , indentify boot type , maybe IDE or CDROM
 * int selected_menu, indentify current menu has been selected.
 * return how many menu show on screen. -1 for error.
*********************************************************************/

static int draw_menu(int flag, int selected_menu)
{
	char buff[MENU_TITLE_BUF_LEN + 1];
	int i;
	int bgcolor;

	i = 0;
	//Draw system internel menu,depends on hardware condition.
	switch(flag)
	{
		case IDE:
			if (has_cdrom == 1)
			{
				sprintf(buff, "    Boot from cdrom");
				if( selected_menu == i+ menu_start )//if current item is selected, then highlight it.
					bgcolor = SELECTED_BGCOLOR;
				else
					bgcolor = UNSELECTED_BGCOLOR;
				empty_line (i + MENU_START_LINE, bgcolor);
				gui_print (i + MENU_START_LINE, LINE_BEGIN, 0, TEXT_COLOR, bgcolor, (unsigned char *)buff);
				_set_font_color ();
				i++;
			}
			break;
		case CDROM:
			sprintf(buff, "    Boot from Harddisk");
			if( selected_menu == i+ menu_start )//if current item is selected, then highlight it.
				bgcolor = SELECTED_BGCOLOR;
			else
				bgcolor = UNSELECTED_BGCOLOR;
			empty_line (i + MENU_START_LINE, bgcolor);
			gui_print (i + MENU_START_LINE, LINE_BEGIN, 0, TEXT_COLOR, bgcolor, (unsigned char *)buff);
			_set_font_color ();
			i++;
			break;
		default:
			return -1;
	}
	//Draw the boot menus.
	for (; i < menu_end - menu_start + 1 + ex_menu_count ; i++)
	{
		sprintf(buff, "    %s", menu_items[i + menu_start-1-ex_menu_count].title);
		cut_string(buff);
		if( selected_menu == i+ menu_start ) //if current item is selected, then highlight it.
			bgcolor = SELECTED_BGCOLOR;
		else
			bgcolor = UNSELECTED_BGCOLOR;
		empty_line (i + MENU_START_LINE, bgcolor);
		gui_print ( i + MENU_START_LINE, LINE_BEGIN, 0, TEXT_COLOR, bgcolor, (unsigned char *)buff);
		//Check selected menu item position, and display arrow on screen if can scroll screen.
		if (i == ex_menu_count || i == menu_end - menu_start + ex_menu_count)
		{
			if(menu_start > 1 && i == ex_menu_count )// if can scroll up.
				sprintf(buff, "%c", DISP_UP);
			//else if (ex_menu_count <=0 && menu_end < menu_len && i == menu_end - menu_start) //if can scroll down
			else if ( menu_end < menu_len - ex_menu_count && i == menu_end - menu_start + ex_menu_count) //if can scroll down
				sprintf(buff, "%c", DISP_DOWN);
			else
				sprintf(buff, " ");
			gui_print (i + MENU_START_LINE, LINE_BEGIN - 1, 0, TEXT_COLOR, bgcolor, (unsigned char *)buff);
			gui_print (i + MENU_START_LINE, LINE_END - 1, 0, TEXT_COLOR, bgcolor, (unsigned char *)buff);
		}

		_set_font_color ();
	}
	//Draw empy_line to fill menus,if need to fill.
	for (i = menu_end - menu_start + 1 + ex_menu_count; i< MAX_MENU_ITEMS_SHOW ; i++)
		empty_line(i + MENU_START_LINE, UNSELECTED_BGCOLOR);
	_set_font_color();
	return i + 2;
}

static int draw_frame()
{
	draw_line (0);
//	video_console_print ( (80 - MENU_TITLE_LEN) / 2, 1, MENU_TITLE);
	video_console_print ( (get_console_cols() - MENU_TITLE_LEN) / 2, 1, MENU_TITLE);
	draw_line (2);
	draw_line ( MAX_MENU_ITEMS_SHOW + MENU_START_LINE);
}

static int print_boot_menu(int flag)
{
	int i;
	char buff[MENU_TITLE_BUF_LEN + 1 ];//width of a line.
	int dly;
	unsigned int cnt;
	int selected = 0;
	unsigned show_menu = 1; //Indentify for show menu for user or not.
	char ch;
#ifdef KEY_INPUT_CHOOSE
#define KEY_BUF_LEN 3
	char key_buf[KEY_BUF_LEN+1]={0};
	int key_buf_index=0;
#endif
	int j = 0;
	int dly_pos = 0;

	i = 0;
	selected = atoi(get_option_value("default")) + 1;
	if(selected <= 0 || selected > menus_num)
		selected = 1;
	ex_menu_count = extra_menu (flag);
	selected += ex_menu_count;//first menu item must be extra menu.
	show_menu = atoi(get_option_value("showmenu")) ;
	if(show_menu == 1) //show menu? true, Display menu on screen.
	{
		menu_len = menus_num + ex_menu_count;
		//calculate the which menu item will be the first item to show and whch will be show as last in menus.
		if(menu_len > MAX_MENU_ITEMS_SHOW) //if total menus great the MAX menus to show.
		{
			if(selected <= MAX_MENU_ITEMS_SHOW )
			{
				menu_start = 1;
				menu_end = MAX_MENU_ITEMS_SHOW - ex_menu_count;
			}
			else if(MAX_MENU_ITEMS_SHOW + selected >= menu_len)
				{
					menu_start = menu_len - MAX_MENU_ITEMS_SHOW ;
					menu_end = MAX_MENU_ITEMS_SHOW - ex_menu_count;
				}
				else
				{
					menu_start = selected;
					menu_end = MAX_MENU_ITEMS_SHOW ;
				}
		}
		else
		{
			menu_start = 1;	
			menu_end = menu_len - ex_menu_count;
		}
		i = draw_menu (flag, selected);
		if( i<0 )
			return -1;
		i += MENU_START_LINE - 1;
		draw_frame();
	}
	if( show_menu == 1 ) //Show menu ,get user setting of timeout and display information.
	{
		sprintf (buff, "Boot: %s    ", menu_items[selected-1-ex_menu_count].kernel);
		cut_string(buff);
		video_console_print(1, i, (unsigned char *)buff);
		dly = atoi(get_option_value("timeout"));
		if(dly < 0 )
			dly = 5;
		draw_help ( i + 2 );
	}
	else // Don't show menu, we set timeout to 5 seconds.
		dly = 5;
	
	if(dly > MAX_TIME_OUT)
		dly = MAX_TIME_OUT ;
	if(dly > 0)
	{
		if( show_menu == 1 ) //Show menu , display timeout information.
		{
			sprintf(buff, "%d(s)", dly);
			dly_pos = LINE_END - strlen(buff) - 2;

			gui_print(selected - menu_start + MENU_START_LINE, dly_pos, 0, TEXT_COLOR, SELECTED_BGCOLOR, (unsigned char *)buff);
			_set_font_color ();
		}
		else
		{
			sprintf(buff, "Booting system in [%d] second(s)    ", dly);
			video_console_print(1, i + 1, (unsigned char *)buff);
		}

		j = 1;
		ioctl(STDIN, FIONBIO, &j);
		ioctl(STDIN, FIOASYNC, &j);
	
		j = 0;
		do {
			ioctl (STDIN, FIONREAD, &cnt);
			if (j == 9)
			{
				if( show_menu == 1 )
				{
					sprintf(buff, "%d(s)", --dly);
					empty_line_part (selected - menu_start + MENU_START_LINE, dly_pos, LINE_END, SELECTED_BGCOLOR);
					gui_print(selected - menu_start + MENU_START_LINE , LINE_END - strlen(buff) - 2, 0, TEXT_COLOR, SELECTED_BGCOLOR, (unsigned char *)buff);
					_set_font_color ();
				}
				else
				{
					sprintf(buff, "Booting system in [%d] second(s)    ", --dly);
					video_console_print(1, i + 1, (unsigned char *)buff);
				}
				j = 0;
			}
			delay(100000);
			j++;
		} while (dly != 0 && cnt == 0);
	}
	if (cnt > 0)
	{
		ch = getchar();
		draw_menu(flag,selected);
		if( strchr("\n\r",ch) != NULL ) // User press ENTER, exit loop.
		{
			video_cls();
			if( do_cmd_boot_load( selected -1 - ex_menu_count, flag) < 0 )
			{
				video_cls();
				draw_frame ();
				draw_help (i+2);
				draw_menu (flag, selected);
				ch = getchar();
			}
		}
	}
	else
	{	
		// Time out, run default menu item.
		video_cls();
		if( do_cmd_boot_load( selected -1 - ex_menu_count, flag) < 0 )
		{
			//Failed, back to main menu.
			video_cls();
			draw_frame ();
			draw_help (i+2);
			draw_menu (flag, selected);
			ch = 'a';
			cnt = 1;
		}
	}

	if (show_menu == 0) // Don't show menu.
		return selected -1 - ex_menu_count;

#ifdef KEY_INPUT_CHOOSE
	sprintf(key_buf,"%d",selected);
	key_buf_index = strlen(key_buf)-1;
#endif

	empty_line(i+1,UNSELECTED_BGCOLOR);
/*	if(cnt > 0 && strchr("\n\r", ch)) {
		cnt = 0;
	}
	else if (cnt > 0)*/
	if (cnt > 0)
	{
		while (1)
		{
			if (strchr("\n\r", ch))
			{
				if (selected > menu_len || selected <= 0)
				{	
					ch = getchar();
					continue;
				}
				else
				{
					video_cls();
					if( do_cmd_boot_load( selected - 1 - ex_menu_count, flag) < 0 )
					{
						video_cls();
						draw_frame ();
						draw_help (i+2);
						draw_menu (flag, selected);
						ch = getchar();
					}
				}
				//break;
			}
			
#ifdef KEY_INPUT_CHOOSE
			if (ch < '0' || ch > '9')
			{
#endif
				switch( ch )
				{
#ifdef KEY_INPUT_CHOOSE
					case 127:  //BACKSPACE delete input data.
						if(key_buf_index < 0)
						{
							ch = getchar();
							continue;
						}
						key_buf[key_buf_index]='\0';
						if( key_buf_index > 0 )
							key_buf_index--;
						else
							key_buf_index = -1;
						break;
#endif
					case 66:// KEY DOWN,PAGE DOWN press.
						if(selected < 1)
							selected = 1;
						else
						{
							if(selected >= menu_len)
								selected = menu_len;
							else
							{
								selected++;
								if(selected > menu_end + ex_menu_count)
								{
									menu_start++;
									menu_end++;
								}
							}
						}
#ifdef KEY_INPUT_CHOOSE
						sprintf(key_buf,"%d",selected);
						key_buf_index = strlen(key_buf)-1;
#endif
						break;
					case 65://KEY UP,PAGE UP press.
						if(selected > menu_len)
							selected = menu_len;
						else
						{
							if(selected <= 1)
								selected = 1;
							else
							{
								selected--;
								if(selected < menu_start + ex_menu_count)
								{
									if(menu_start >1)
									{
										menu_start--;
										menu_end--;
									}
								}

							}
						}
#ifdef KEY_INPUT_CHOOSE
						sprintf(key_buf,"%d",selected);
						key_buf_index = strlen(key_buf)-1;
#endif
						break;
					case 70:// END press, then go to the last menuitem.
						menu_start = menu_start + menu_len - menu_end - ex_menu_count ;
						menu_end = menu_len - ex_menu_count;
						selected = menu_len;
						break;
					case 72:// HOME press, then go to the first menuitem.
						menu_end = menu_end - menu_start + 1 ;
						menu_start = 1;
						selected = 1;
						break;
					case '[':// ESC press 0x1b
					case 27:// ESC press 0x1b
					default:
						ch = getchar();
						continue;
						break;
				}
#ifdef KEY_INPUT_CHOOSE
			}
			else // is digit key.
			{
				if(key_buf_index >= KEY_BUF_LEN-1)
					key_buf_index = 0;
				else
					key_buf_index++;
				key_buf[key_buf_index] = ch;
				key_buf[key_buf_index+1] = '\0';
			}
			if(key_buf[0] == 0 )
			{
				sprintf(buff, "Boot:           ");
				selected = -1;
			}
			else
			{
				selected = atoi( key_buf );
#endif
				if(ex_menu_count >0 && selected <= ex_menu_count )
					sprintf(buff, "Boot:         ");
				else
				{
					cut_string(buff);
					sprintf(buff, "Boot: %s    ", menu_items[ selected-1-ex_menu_count ].kernel);
					//sprintf(buff, "Boot: select=%d,start=%d,end=%d,len=%d,num=%d    ", selected,menu_start,menu_end,menu_len,menus_num);
				}
#ifdef KEY_INPUT_CHOOSE
			}
#endif
			empty_line(i,UNSELECTED_BGCOLOR);
			video_console_print(1, i, (unsigned char *)buff);
#ifdef SHOW_ARGS_FOR_KERNEL
			sprintf(buff, "Boot: %s    ", menu_items[selected-1-ex_menu_count].args);
			video_console_print(1, i+1, (unsigned char *)buff);
#endif
			draw_menu(flag,selected);
			ch = getchar();
		}			
	}
	
	video_cls();
	return selected-1-ex_menu_count;
}

static int OpenLoadConfig(const char* filename)
{
	int bootfd;
	if ((bootfd = open(filename, O_RDONLY | O_NONBLOCK)) < 0) {
		return -1;
	}
	return bootfd;
}

static int boot_load(int index)
{
	char cmd[1025];
	int is_root = 0;
//#define MENU_DEBUG
#ifdef MENU_DEBUG
	int stat;
#endif
	
	if( index >= menus_num )
		return -2;
	
	if( menu_items[index].kernel == NULL )
		return -1;
	
	if (menu_items[index].root[0] != '\0')
	{
		is_root = 1;
	}
		
	printf("Now booting the %s\n",menu_items[index].title);
	if(menu_items[index].kernel[0] != '\0')
	{
		memset(cmd, 0, sizeof(cmd));
		strncpy(cmd, menu_items[index].kernel, 5);
		if (is_root && strcasecmp(cmd, "/dev/") != 0 &&
			cmd[0] != '(')
		{
			sprintf(cmd, "load %s/%s", menu_items[index].root, menu_items[index].kernel);
		}
		else
		{
			sprintf(cmd, "load %s", menu_items[index].kernel);
		}

#ifdef MENU_DEBUG
		printf("%s\n",cmd);
		stat=do_cmd(cmd);
		printf("Load Kernel return %d\n",stat);
		if(stat)
#else
		if(do_cmd(cmd))
#endif
			return -1;
	}
	else
	{
		printf("No kernel to load for current menu item.\n");
		return -1;
	}
	
	if(menu_items[index].initrd[0] != '\0')
	{
		memset(cmd, 0, sizeof(cmd));
		strncpy(cmd, menu_items[index].initrd, 5);
		if (is_root && strcasecmp(cmd, "/dev/") != 0 &&
			cmd[0] != '(')
		{
			sprintf(cmd, "initrd %s/%s", menu_items[index].root, menu_items[index].initrd);
		}
		else
		{
			sprintf(cmd, "initrd %s", menu_items[index].initrd);
		}

#ifdef MENU_DEBUG
		printf("%s\n",cmd);
		stat=do_cmd(cmd);
		printf("Load initrd return %d\n",stat);
		if(stat)
#else
		if(do_cmd(cmd))
#endif
			return -1;
	}

	if(menu_items[index].args[0] != '\0')
	{
#ifdef NOTEBOOK
		sprintf(cmd, "g -S %s", menu_items[index].args);
#else
		sprintf(cmd,"g %s",menu_items[index].args);
#endif
		
#ifdef MENU_DEBUG
		printf("%s\n",cmd);
		stat=do_cmd(cmd);
		printf("go command return %d\n",stat);
		if(stat)
#else
		if(do_cmd(cmd))
#endif
			return -1;
	}
	else
	{
		printf("No arguments pass to kernel in current menu item.\n");
		return -1;
	}
	return 0;
}

static int do_cmd_boot_load(int boot_id, int device_flag)
{
	int ret = -1;
	struct termio sav;
	if (boot_id < menus_num)
	{
		ret = boot_load(boot_id);
		if (ret <0 )
		{
			printf("\nPress any key to continue ...\n");
			getchar();
		}
		return ret;
	}
	
	ioctl (STDIN, CBREAK, &sav);
	if (device_flag == IDE)
	{
		ret=do_cmd_menu_list(CDROM, "/dev/iso9660/usb0/boot.cfg");
	}
	else if (device_flag == CDROM)
	{
		ret=do_cmd_menu_list(IDE, "/dev/fs/ext2@wd0/boot.cfg");
	}
	ioctl (STDIN, TCSETAF, &sav);

	return ret;
}

static int do_cmd_menu_list(int flag, const char* path)
{
	int ret = 0;
	char errbuf[1024];
	char ch;

	video_cls();
	
	ret = do_list_menu(flag, path);
	if (ret == 0)
	{
		return 0;
	}

	if (ret == -1)
	{
		printf(errbuf, "File don't exist: [%s]", path);
	}
#ifdef OLE_CODE	
	while (1)
	{
		gui_print(15, 0, 10, TEXT_COLOR, 0, errbuf);
		if (flag == IDE)
		{
			gui_print(16, 0, 10, TEXT_COLOR, 0, "Press key [C]entry command line, [Q]reboot");
		}
		else
		{
			gui_print(16, 0, 10, TEXT_COLOR, 0, "Press key [D]boot from Hard disk, [C]entry command line, [Q]reboot");
		}
		
		ch = getchar();
		if (ch == 'c')
		{
			video_cls();
			return 0;
		}
		
		if (ch == 'q')
		{
			tgt_reboot();
		}

		if (ch == 'd' && flag == CDROM)
		{
			return do_cmd_menu_list(IDE, "/dev/fs/ext2@wd0/boot.cfg");
		}
	}
#endif
	return -1;
}

static int do_list_menu(int flag, const char* path)
{
	int flags = 0;
	int bootfd;
	ExecId id;
	int ret;
	int boot_id;

	bootfd = OpenLoadConfig(path);
	if (bootfd == -1)
	{
		return -1;
	}

	id = getExec("txt");
	if (id != NULL) {
		ret = menu_list_read(id, bootfd, flags);
		if (ret != 0)
		{
			printf("\nCannot found and boot item in boot configure file.");
			printf("\nPress any key to continue ...\n");
			getchar();
			close(bootfd);
			return -2;
		}
	}else{
		printf("[error] this pmon can't read file!");
		close(bootfd);
		return -3;
	}
	close(bootfd);

	boot_id = print_boot_menu(flag);
	if (boot_id == -1)
	{
		return -4;
	}

	return do_cmd_boot_load(boot_id, IDE);
}

int cmd_menu_list (int ac, char *av[])
{
	char path[256] = {0};
	int err;
	int dflag = -1;
	char c;
	int ret;
	struct termio sav;

	err = 0;
	optind = 0;
	optarg = NULL;

	while ((c = getopt(ac, av, "d:")) != EOF)
	{
		switch (c)
		{
		case 'd':
			if (strcmp(optarg, "cdrom") == 0)
			{
				dflag = CDROM;
			}
			else
			{
				dflag = IDE;
			}
			break;
		default:
			err++;
			break;
		}
	}

	if (err > 0)
	{
		return EXIT_FAILURE;
	}

	if (dflag == -1)
	{
		return EXIT_FAILURE;
	}

	strcpy(path, av[optind]);

	ioctl (STDIN, CBREAK, &sav);
	ret = do_cmd_menu_list(dflag, path);
	ioctl (STDIN, TCSETAF, &sav);
	return ret != 0 ? EXIT_FAILURE : 0;
}

int check_ide()
{
	int ret;

	ret = check_config("/dev/fs/ext2@wd0/boot.cfg");
	if (ret == 1)
	{
		return 1;
	}

	ret = check_config("/dev/fs/ext2@wd0/boot/boot.cfg");
	if (ret == 1)
	{
		return 1;
	}
	return 0;
}

int check_cdrom()
{
	int ret;
	has_cdrom = 0;
	ret = check_config("/dev/iso9660/usb0/boot.cfg");
	if (ret == 1)
	{
		has_cdrom = 1;
		return 1;
	}

	ret = check_config("/dev/iso9660/usb0/boot/boot.cfg");
	if (ret == 1)
	{
		has_cdrom = 1;
		return 1;
	}
	
	return 0;
}

int check_config (const char * file)
{
	int bootfd;
	bootfd = OpenLoadConfig (file);
	if( bootfd == -1 )
		return 0;
	close(bootfd);
	return 1;
}

int cmd_load_flush(int ac, char *av[])
{
	char * flash_rom;
	char buf[LINESZ] = {0};
	if( ac == 2 )
	{
		sprintf(buf,"load -r -f bfc00000 %s",av[1]);
	}
	else
	{
		flash_rom=getenv("romfile");
		if(flash_rom)
			sprintf(buf,"load -r -f bfc00000 %s",flash_rom);
		else
			sprintf(buf,"load -r -f bfc00000 tftp://192.168.10.91/gzrom.bin");
	}
	do_cmd(buf);
	return 0;
}

/*
 *  Command table registration
 *  ==========================
 */
static const Cmd MenuListCmd[] =
{
	{"RAYS Commands for PMON 2000"},
	{"bl",	"-d cdrom/ide boot_config_file",0, "Load Boot menu from config file", cmd_menu_list, 2, 4, 0},
	{"fload", "firmware file", 0, "Update BIOS from file.", cmd_load_flush, 0, 2, CMD_ALIAS},
	{0, 0}
};

static void init_cmd __P((void)) __attribute__ ((constructor));

static void
init_cmd()
{
	cmdlist_expand(MenuListCmd, 1);
}

