#ifndef __KEY_DEFS_H__
#define __KEY_DEFS_H__

#define VK_L_CTRL		0x1D
#define	VK_L_SHIFT		0x2A
#define	VK_R_SHIFT		0x36
#define	VK_L_ALT		0x38

#define VK_CAPS_LOCK	0x3A
#define VK_NUM_LOCK		0x45
#define VK_SCROLL_LOCK	0x46
#define VK_PAGE_UP		0x49
#define VK_PAGE_DOWN	0x51
#define VK_KP_DEL		0x53


#define KEY_PRESS_MASK 0x80
//
// Keyboard LEDs
//
#define LED_NUM_LOCK            2
#define LED_SCROLL_LOCK         1
#define LED_CAPS_LOCK           4

//  
// Control Keys
//

#define CK_LSHIFT               0x01
#define CK_LALT                 0x02
#define CK_LCTRL                0x04
#define CK_RSHIFT               0x10
#define CK_RALT                 0x20
#define CK_RCTRL                0x40
#define CK_L_CTRL_ALT			(CK_LALT | CK_LCTRL)
#define CK_R_CTRL_ALT			(CK_RALT | CK_RCTRL)

#endif
